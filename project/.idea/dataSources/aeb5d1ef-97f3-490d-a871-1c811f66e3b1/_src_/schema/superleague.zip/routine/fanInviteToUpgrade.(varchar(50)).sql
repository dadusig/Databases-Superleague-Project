CREATE PROCEDURE fanInviteToUpgrade(IN team_name VARCHAR(50))
  BEGIN

DECLARE totalGames INT;

select count(*)
into totalGames
from game
where game.team_host = team_name or game.team_guest=team_name;

SELECT fan.name
from fan
INNER JOIN ticket on (fan.id = ticket.fan_id AND fan.team_name=team_name)
GROUP BY fan.name
having COUNT(*) >= (totalGames/2);



END;
